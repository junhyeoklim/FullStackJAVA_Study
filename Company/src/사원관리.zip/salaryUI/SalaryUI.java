package salaryUI;

public class SalaryUI {
	
	public static void printMenu()
	{
		System.out.println("선택하세요...");
		System.out.println("1. 사원 정보 입력");
		System.out.println("2. 사원 정보 검색");		
		System.out.println("3. 모든 사원정보 보기");
		System.out.println("4. 프로그램 종료");
		System.out.print("선택 : ");
	}
}
